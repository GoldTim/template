create definer = homestead@`%` view productView as
select `study`.`product`.`shopId`    AS `shopId`,
       `study`.`product`.`shipId`    AS `shipId`,
       `study`.`product`.`stockId`   AS `stockId`,
       `study`.`product`.`title`     AS `title`,
       `study`.`product`.`weight`    AS `weight`,
       `study`.`product`.`amount`    AS `amount`,
       `study`.`product`.`type`      AS `type`,
       `study`.`product`.`num`       AS `num`,
       `study`.`product`.`saleCount` AS `saleCount`
from `study`.`product`
where (`study`.`product`.`status` = 0)
order by `study`.`product`.`saleCount` desc;

