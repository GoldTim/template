create definer = homestead@`%` view skuView as
select `study`.`productSku`.`id`        AS `id`,
       `study`.`product`.`shopId`       AS `shopId`,
       `study`.`product`.`shipId`       AS `shipId`,
       `study`.`product`.`stockId`      AS `stockId`,
       `study`.`product`.`title`        AS `title`,
       `study`.`product`.`weight`       AS `weight`,
       `study`.`product`.`amount`       AS `amount`,
       `study`.`product`.`type`         AS `type`,
       `study`.`product`.`num`          AS `num`,
       `study`.`productSku`.`skuId`     AS `skuId`,
       `study`.`productSku`.`colorId`   AS `colorId`,
       `study`.`productSku`.`skuAmount` AS `skuAmount`,
       `study`.`productSku`.`skuNum`    AS `skuNum`,
       `study`.`productSku`.`skuImage`  AS `skuImage`,
       `study`.`product`.`created_at`   AS `created_at`,
       `study`.`product`.`updated_at`   AS `updated_at`
from (`study`.`productSku`
         join `study`.`product` on ((`study`.`productSku`.`stockId` = `study`.`product`.`stockId`)));

