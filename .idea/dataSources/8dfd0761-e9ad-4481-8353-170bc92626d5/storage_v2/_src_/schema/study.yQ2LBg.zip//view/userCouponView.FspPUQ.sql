create view userCouponView as
select `study`.`userCoupon`.`id`         AS `id`,
       `study`.`userCoupon`.`couponId`   AS `couponId`,
       `study`.`userCoupon`.`uId`        AS `uId`,
       `study`.`userCoupon`.`status`     AS `status`,
       `study`.`shopCoupon`.`couponName` AS `couponName`,
       `study`.`shopCoupon`.`type`       AS `type`,
       `study`.`shopCoupon`.`amount`     AS `amount`,
       `study`.`shopCoupon`.`dNum`       AS `dNum`,
       `study`.`shopCoupon`.`startDate`  AS `startDate`,
       `study`.`shopCoupon`.`endDate`    AS `endDate`
from (`study`.`userCoupon`
         join `study`.`shopCoupon` on ((`study`.`shopCoupon`.`id` = `study`.`userCoupon`.`couponId`)));

